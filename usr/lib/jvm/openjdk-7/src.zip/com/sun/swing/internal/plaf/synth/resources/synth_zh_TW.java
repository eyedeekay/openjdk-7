package com.sun.swing.internal.plaf.synth.resources;

import java.util.ListResourceBundle;

public final class synth_zh_TW extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "FileChooser.detailsViewActionLabel.textAndMnemonic", "\u8A73\u7D30\u8CC7\u8A0A" },
            { "FileChooser.detailsViewButtonAccessibleName", "\u8A73\u7D30\u8CC7\u8A0A" },
            { "FileChooser.detailsViewButtonToolTip.textAndMnemonic", "\u8A73\u7D30\u8CC7\u8A0A" },
            { "FileChooser.fileAttrHeader.textAndMnemonic", "\u5C6C\u6027" },
            { "FileChooser.fileDateHeader.textAndMnemonic", "\u4FEE\u6539\u65E5\u671F" },
            { "FileChooser.fileNameHeader.textAndMnemonic", "\u540D\u7A31" },
            { "FileChooser.fileNameLabel.textAndMnemonic", "\u6A94\u6848\u540D\u7A31(&N):" },
            { "FileChooser.fileSizeHeader.textAndMnemonic", "\u5927\u5C0F" },
            { "FileChooser.fileTypeHeader.textAndMnemonic", "\u985E\u578B" },
            { "FileChooser.filesOfTypeLabel.textAndMnemonic", "\u6A94\u6848\u985E\u578B(&T):" },
            { "FileChooser.folderNameLabel.textAndMnemonic", "\u8CC7\u6599\u593E\u540D\u7A31(&N):" },
            { "FileChooser.homeFolderAccessibleName", "\u4E3B\u76EE\u9304" },
            { "FileChooser.homeFolderToolTip.textAndMnemonic", "\u4E3B\u76EE\u9304" },
            { "FileChooser.listViewActionLabel.textAndMnemonic", "\u6E05\u55AE" },
            { "FileChooser.listViewButtonAccessibleName", "\u6E05\u55AE" },
            { "FileChooser.listViewButtonToolTip.textAndMnemonic", "\u6E05\u55AE" },
            { "FileChooser.lookInLabel.textAndMnemonic", "\u67E5\u8A62(&I):" },
            { "FileChooser.newFolderAccessibleName", "\u65B0\u8CC7\u6599\u593E" },
            { "FileChooser.newFolderActionLabel.textAndMnemonic", "\u65B0\u8CC7\u6599\u593E" },
            { "FileChooser.newFolderToolTip.textAndMnemonic", "\u5EFA\u7ACB\u65B0\u8CC7\u6599\u593E" },
            { "FileChooser.refreshActionLabel.textAndMnemonic", "\u91CD\u65B0\u6574\u7406" },
            { "FileChooser.saveInLabel.textAndMnemonic", "\u5132\u5B58\u65BC: " },
            { "FileChooser.upFolderAccessibleName", "\u5F80\u4E0A" },
            { "FileChooser.upFolderToolTip.textAndMnemonic", "\u5F80\u4E0A\u4E00\u5C64" },
            { "FileChooser.viewMenuLabel.textAndMnemonic", "\u6AA2\u8996" },
        };
    }
}
